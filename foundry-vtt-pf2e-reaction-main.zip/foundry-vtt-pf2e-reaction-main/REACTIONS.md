### List of implemented Reactions:
1. Selfish Shield
2. Iron Command
3. Attack Of Opportunity
4. Wicked thorns
5. Glimpse of Redemption
6. Fast Swallow
7. Retributive Strike
8. Ferocity
9. Destructive Vengeance
10. Liberating Step
11. Reactive Gnaw
12. Fast Swallow
13. Vengeful Spite
14. Avenging Bite
15. Nimble Dodge
16. Petrifying Glance
17. Airy Step
18. Opportune Riposte
19. Retaliatory Cleansing
20. Embrace the Pain
21. Furious Vengeance
22. Mage Hunter
23. No Escape
24. Perfect Clarity
25. Tangle of Battle
26. Spiritual Guides
27. Accompany
28. Pirouette
29. Ringmaster's Introduction
30. Sacrifice Armor
31. Shield Wall
32. Denier of Destruction
33. Rapid Response
34. Premonition of Clarity
35. Courageous Opportunity
36. Fiery Retort
37. Reactive Transformation
38. Storm Retribution
39. Verdant Presence
40. Dueling Riposte
41. Farabellus Flip
42. Guardian's Deflection
43. Knight's Retaliation
44. Mirror Shield
45. Reactive Shield
46. Twin Riposte
47. Cheat Death
48. Spell Relay
49. Ruby Resurrection
50. Scapegoat Parallel Self(only first trigger)
51. Convincing Illusion
52. Charmed Life
53. Amulet's Abeyance
54. Ring Bell
55. Implement's Interruption
56. Clever Gambit
57. Schadenfreude
58. Shield Block
59. Cleave
60. Wounded Rage
61. All in my Head
62. Resounding Finale(Only you take damage)
63. Reverberate
64. Everdistant Defense
65. Hit the Dirt!
66. Grit and Tenacity
67. Distracting Explosion
68. Negate Damage
69. You Failed to Account for… This!
70. Foresee Danger
71. Suspect of Opportunity(only attack)
72. Emergency Targe(melee spell?)
73. Align Ki
74. Crane Flutter
75. Deflect Arrow
76. Electric Counter
77. Rippling Spin
78. Impossible Technique(Only enemy’s attack hits)
79. Stand Still
80. Entity's Resurgence
81. Final Spite
82. Cringe
83. Orc Ferocity
84. Squawk!
85. Unexpected Shift
86. Counter Thought
87. Fake Out
88. Mental Static
89. No!!!
90. I'm Not Crying
91. Opportune Backstab
92. Banshee Cry(Spell only)
93. Invigorating Fear
94. Ectoplasmic Shield
95. You're Next
96. Disarming Block
97. Sense The Unseen