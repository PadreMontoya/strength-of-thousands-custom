---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: enhancement
assignees: ''

---

**Is your feature request related to a problem? Please describe.**
Provide a link to feat (https://2e.aonprd.com/Feats.aspx?ID=253)
