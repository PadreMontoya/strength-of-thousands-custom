# Special thanks for all the people who have contributed to this project so far:

The list with a Discord username, possibly a link to a Github profile followed by a brief and description of what this person has contributed.

* [reyzor1991](https://github.com/reyzor1991/) - Started the project, has added most features and bugs.
* [xdy](https://github.com/xdy/) - Idea about grouping messages.
* [apoapostolov](https://github.com/apoapostolov) - Idea about improve recall knowledge.
* [liyu](https://github.com/LiyuNodream) - Add Chinese Translation.
* [DoctorDankovsky](https://github.com/DoctorDankovsky) - Add Localization.