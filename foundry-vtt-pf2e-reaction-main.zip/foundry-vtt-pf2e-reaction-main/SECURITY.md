# Security Policy

## Supported Versions

Only the latest version.

## Reporting a Vulnerability

Create an issue on [Github](https://github.com/reyzor1991/foundry-vtt-pf2e-reaction/issues) explaining the problem.